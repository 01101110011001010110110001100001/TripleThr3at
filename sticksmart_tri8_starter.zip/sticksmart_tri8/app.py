"""StickSmart TRI-8: initial API skeleton and draft data contracts.

Contract fields are provisional until Nela and Kemuel approve them.
"""
from datetime import datetime, timezone
from typing import Literal
from uuid import UUID

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="StickSmart Backend", version="0.1.0")


class Drill(BaseModel):
    id: str = Field(min_length=1)
    name: str = Field(min_length=1)
    description: str = ""


class WorkoutStep(BaseModel):
    drill_id: str = Field(min_length=1)
    duration_seconds: int = Field(gt=0)
    rest_seconds: int = Field(default=0, ge=0)


class Workout(BaseModel):
    id: UUID
    name: str = Field(min_length=1)
    steps: list[WorkoutStep] = Field(min_length=1)


class TrackingEvent(BaseModel):
    timestamp_ms: int = Field(ge=0)
    event_type: Literal["rep", "feedback", "tracking_lost", "tracking_restored"]
    drill_id: str = Field(min_length=1)
    quality: Literal["valid", "invalid", "unknown"] | None = None
    message: str | None = None


class Session(BaseModel):
    id: UUID
    workout_id: UUID
    status: Literal["active", "paused", "finished", "aborted"]
    started_at: datetime
    active_seconds: float = Field(ge=0)


class SessionResult(BaseModel):
    session_id: UUID
    elapsed_seconds: float = Field(ge=0)
    active_seconds: float = Field(ge=0)
    completed: bool
    valid_reps: int = Field(ge=0)
    invalid_reps: int = Field(ge=0)


@app.get("/health")
def health():
    return {"status": "ok", "timestamp": datetime.now(timezone.utc).isoformat()}


@app.get("/api/v1/drills", response_model=list[Drill])
def list_drills():
    # TRI-13 will replace this placeholder with Kemuel's seeded database catalog.
    raise HTTPException(status_code=501, detail="Drill storage is not implemented yet")
