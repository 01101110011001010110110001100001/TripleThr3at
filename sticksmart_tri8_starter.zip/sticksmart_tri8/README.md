# StickSmart backend — TRI-8 starter

This is a **standalone draft**, not a patch against the real repository. Existing GitHub code could not be accessed. It defines provisional Python request/response models and a health check. It deliberately does not claim to have working database persistence, auth, or session lifecycle features.

## Run locally

```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# Linux/macOS:
# source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload
```

- `GET http://127.0.0.1:8000/health` returns `{"status":"ok","timestamp":"..."}`.
- `GET http://127.0.0.1:8000/docs` opens the FastAPI schema UI.
- `GET /api/v1/drills` returns HTTP 501 until TRI-13 is implemented; it never pretends real catalog data exists.
- Run `pytest -q` for the included smoke tests.

## Proposed contracts (discuss before implementation)

| Resource | Proposed endpoint | Behavior |
|---|---|---|
| Health | `GET /health` | Server readiness smoke check |
| Catalog | `GET /api/v1/drills` | Return seeded drills from Kemuel's SQLite DB (TRI-13) |
| Workouts | `GET /api/v1/workouts` | List presets and user-created workouts (TRI-13) |
| Workouts | `POST /api/v1/workouts` | Create a named workout with ordered steps (TRI-13) |
| Workouts | `GET /api/v1/workouts/{id}` | Read one workout (TRI-13) |
| Workouts | `PUT /api/v1/workouts/{id}` | Update a custom workout (TRI-13) |
| Sessions | `POST /api/v1/sessions` | Start a session from a workout (TRI-14) |
| Sessions | `POST /api/v1/sessions/{id}/pause` | Pause active timer (TRI-14) |
| Sessions | `POST /api/v1/sessions/{id}/resume` | Resume paused timer (TRI-14) |
| Sessions | `POST /api/v1/sessions/{id}/finish` | Idempotent completion/result save (TRI-14) |
| Sessions | `POST /api/v1/sessions/{id}/abort` | Stop without treating as complete (TRI-14) |
| Tracking | `POST /api/v1/sessions/{id}/events` | Receive timestamped CV events (TRI-19) |
| Results | `GET /api/v1/sessions/{id}/result` | Read a session result (TRI-14/25) |

Only `/health` is implemented; `/api/v1/drills` is explicitly not implemented (HTTP 501). The rest are *proposals*, not implemented routes.

### Example workout request

```json
{
  "name": "Stickhandling basics",
  "steps": [
    {"drill_id": "drill-1", "duration_seconds": 45, "rest_seconds": 15},
    {"drill_id": "drill-2", "duration_seconds": 60, "rest_seconds": 0}
  ]
}
```

### Example future session result

```json
{
  "session_id": "c157b524-7aa1-4eb6-8f2d-a6b419e242aa",
  "elapsed_seconds": 130,
  "active_seconds": 105,
  "completed": true,
  "valid_reps": 18,
  "invalid_reps": 2
}
```

### Proposed error shape

```json
{"error": {"code": "unknown_drill", "message": "Drill not found", "details": {"drill_id": "missing"}}}
```

**Not implemented:** Custom error formatter; FastAPI's default 422 response remains until approved. Do not promise the proposed error shape as live behavior.

## Decisions needed from Nela and Kemuel

1. Compare fields with final Figma, especially ordered steps, rests, guest behavior, result labels, and visible tracking feedback.
2. Obtain the existing SQLite schema and catalog IDs; do not overwrite Kemuel's completed TRI-9 work.
3. Decide how to identify guests (ephemeral client key, browser session, or other mechanism), how long to keep their results, and whether actual sign-in belongs in the release.
4. Define which event types and quality labels the C++ tracking pipeline can *actually* provide. Unknown/occluded intervals cannot count as known valid reps.
5. Agree on UTC timestamps, client/server clock rules, and result-save idempotency semantics.
6. Confirm server framework and integration conventions with the current repository before merging.

## TRI-8 handoff checklist

- [x] Draft endpoint and request/response contracts
- [x] Python backend skeleton with real health route
- [x] Basic health/placeholder tests authored
- [ ] Verify installation and test execution against real environment
- [ ] Inspect existing backend, database schema and final Figma
- [ ] Agree with Nela and Kemuel on event, workout, guest/auth fields
- [ ] Implement shared error schema (if accepted)
- [ ] Teammate review and integrate into repository
