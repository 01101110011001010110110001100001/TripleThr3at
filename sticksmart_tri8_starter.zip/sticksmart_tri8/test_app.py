from fastapi.testclient import TestClient
from app import app

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"
    assert "timestamp" in response.json()


def test_drill_placeholder_is_explicit():
    response = client.get("/api/v1/drills")
    assert response.status_code == 501
